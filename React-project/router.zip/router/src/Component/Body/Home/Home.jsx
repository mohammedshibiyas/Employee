import React from 'react';
import './Home.css';
import { Link } from 'react-router-dom';
import { MdDelete } from "react-icons/md";
import { FaEye } from "react-icons/fa";
import { MdEdit } from "react-icons/md";
const Home = () => {
  return (
    <div>
           <table className='tablemain'>
    <thead>
      <tr>
        <th className='id'>User ID</th>
        <th className='username'>Username</th>
        <th className='action'>Action</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>1</td>
        <td>Lokesh</td>
        <td>
          <button class="view-btn"><FaEye /></button>
          <button class="edit-btn"><MdEdit /></button>
          <button class="delete-btn"><MdDelete /></button>
        </td>
      </tr>

      <tr>
        <td>2</td>
        <td>Paul jak</td>
        <td>
          <button class="view-btn"><FaEye /></button>
          <button class="edit-btn"><MdEdit /></button>
          <button class="delete-btn"><MdDelete /></button>
        </td>
      </tr>
    
    </tbody>
  </table>
    </div>
  )
 
}

export default Home
